---
title: Project Threads
subtitle: subtitle lorem ipsum dolor sit amet consectetur.
image: https://raw.githubusercontent.com/BlackrockDigital/startbootstrap-agency/master/src/assets/img/portfolio/01-full.jpg
alt: Shirts on a hanger

caption:
  title: Threads
  subtitle: Illustration
  thumbnail: https://raw.githubusercontent.com/BlackrockDigital/startbootstrap-agency/master/src/assets/img/portfolio/01-thumbnail.jpg
---
Use this area to describe your project. **Markdown** supported. This entry (project1.md) uses links for the image sources. All other projects in the portfolio use local images. Both work just fine! Lorem ipsum dolor sit amet, consectetur adipisicing elit. 

{:.list-inline}
- Date: January 2017
- Client: Threads
- Category: Illustration

