---
caption: #what displays in the portfolio grid:
  title: Example
  subtitle: subtitle
  thumbnail: https://place-hold.it/400x300
  
#what displays when the item is clicked:
title: Title
subtitle: subtitle lorem ipsum dolor sit amet consectetur.
image: https://place-hold.it/400x300 #main image, can be a link or a file in assets/img/portfolio
alt: image alt text

---
Use this area to describe your project. **Markdown** supported.

optional info list (delete if not using):

{:.list-inline} 
- Date: 
- Client: 
- Category: 

